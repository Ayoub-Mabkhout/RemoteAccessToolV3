# OpenApiDefinition.RemoteServerApi

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getProcessList**](RemoteServerApi.md#getProcessList) | **GET** /remote/processes | 
[**screenshot**](RemoteServerApi.md#screenshot) | **GET** /remote/screenshot | 
[**systemReboot**](RemoteServerApi.md#systemReboot) | **GET** /remote/reboot | 
[**systemShutDown**](RemoteServerApi.md#systemShutDown) | **GET** /remote/shutdown | 

<a name="getProcessList"></a>
# **getProcessList**
> [&#x27;String&#x27;] getProcessList()



### Example
```javascript
import {OpenApiDefinition} from 'open_api_definition';

let apiInstance = new OpenApiDefinition.RemoteServerApi();
apiInstance.getProcessList((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

**[&#x27;String&#x27;]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="screenshot"></a>
# **screenshot**
> [&#x27;Blob&#x27;] screenshot()



### Example
```javascript
import {OpenApiDefinition} from 'open_api_definition';

let apiInstance = new OpenApiDefinition.RemoteServerApi();
apiInstance.screenshot((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

**[&#x27;Blob&#x27;]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: image/jpeg

<a name="systemReboot"></a>
# **systemReboot**
> systemReboot()



### Example
```javascript
import {OpenApiDefinition} from 'open_api_definition';

let apiInstance = new OpenApiDefinition.RemoteServerApi();
apiInstance.systemReboot((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="systemShutDown"></a>
# **systemShutDown**
> systemShutDown()



### Example
```javascript
import {OpenApiDefinition} from 'open_api_definition';

let apiInstance = new OpenApiDefinition.RemoteServerApi();
apiInstance.systemShutDown((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

